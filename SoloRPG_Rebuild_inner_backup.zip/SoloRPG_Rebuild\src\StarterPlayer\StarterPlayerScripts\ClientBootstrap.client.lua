-- StarterPlayerScripts/ClientBootstrap.client.lua
print("[ClientBootstrap] Client avviato.")
