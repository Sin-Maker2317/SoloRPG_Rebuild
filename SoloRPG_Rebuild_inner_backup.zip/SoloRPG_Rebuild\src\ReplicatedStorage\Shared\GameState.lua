-- ReplicatedStorage/Shared/GameState.lua

return {
	HospitalChoice = "HospitalChoice",
	AwakeningDungeon = "AwakeningDungeon",
	SoloGateTutorial = "SoloGateTutorial",
	GuildGateTutorial = "GuildGateTutorial",
	OpenWorld = "OpenWorld"
}
